package com.karmeeo.bjming;

/**
 * Created by bjming on 16-5-7.
 */
public interface Phone {
    public void call(String to);
}
