package com.karmeeo.bjming;

/**
 * Created by bjming on 16-5-7.
 */
public class User implements Person{
    private Phone phone;
    private String name;
    private String type;

    public Phone getPhone() {
        return phone;
    }

    public void setPhone(Phone phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public User(Phone phone, String name, String type) {
    }

    public void dial(String to) {
        System.out.println(to);
    }
}
