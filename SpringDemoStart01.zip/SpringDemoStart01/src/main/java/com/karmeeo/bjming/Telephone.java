package com.karmeeo.bjming;

/**
 * Created by bjming on 16-5-7.
 */
public class Telephone implements Phone{
    private String phone;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void call(String to) {
        System.out.println(to);
    }
}
