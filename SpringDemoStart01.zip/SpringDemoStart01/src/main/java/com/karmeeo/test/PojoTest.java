package com.karmeeo.test;

import com.karmeeo.bjming.Person;
import com.karmeeo.bjming.Telephone;
import com.karmeeo.bjming.User;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by bjming on 16-5-7.
 */
public class PojoTest {
    private static ApplicationContext context;

    public static void main(String[] args) {
        context = new ClassPathXmlApplicationContext("bean.xml");
        User p = (User) context.getBean("user1");
        p.dial("13588317428");

    }
}
